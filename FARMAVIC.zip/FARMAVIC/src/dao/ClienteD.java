
package dao;


public class ClienteD extends conexion implements ICRUD<Cliente>{
    
}
