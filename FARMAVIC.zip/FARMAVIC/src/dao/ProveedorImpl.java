
package dao;

import java.sql.PreparedStatement;
import modelo.Proveedorm;


public class ProveedorImpl extends conexion implements ICRUD<Proveedorm>
 {

    @Override
    public void registrar(Proveedorm modelo) throws Exception {
        
        String sql = "INSERT INTO PROVEEDOR (NOMPROV, RUCPROV, TELPROV, EMAPROV, TIPPROV, NCOMPROV, ABREPROV, DIRPROV, IDUBI, ESTPROV) VALUES  (?,?,?,?,?,?,?,?,?,?)";
                
        try {
            PreparedStatement ps = this.conectar().prepareStatement(sql);
            ps.setString(1, modelo.getNOMPROV());
            ps.setString(2, modelo.getRUCPROV());
            ps.setString(3, modelo.getTELPROV());
            ps.setString(4, modelo.getEMAPROV());
            ps.setString(5, modelo.getTIPPROV());
            ps.setString(6, modelo.getNCOMPROV());
            ps.setString(7, modelo.getABREVPROV());
            ps.setString(8, modelo.getDIRPROV());
            ps.setString(9, modelo.getIDUBI());
            ps.setString(10, "A");
            ps.executeUpdate(); //ejecuta y actualiza
            ps.close(); //cierra ps
        } catch (Exception e) {
            System.out.println("Error al INGRESAR ProveedorImpl " + e.getMessage());
        }
        
    }

    @Override
    public void modificar(Proveedorm object) throws Exception {
        
    }

    @Override
    public void eliminar(int codigo) throws Exception {
         
    }


    @Override
    public void listar() {
        
    }
    
    
    
    
}
