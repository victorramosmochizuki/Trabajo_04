
package modelo;


public class Cliente {
    

    
}
