package modelo;

public class Proveedorm {

    
    //String RUCPROV, TELPROV, EMAPROV, TIPPROV, NCOMPROV, ABREVPROV, DIRPROV, IDUBI, ESTPROV;
    
    private int IDPROV;
    private String NOMPROV;
    private String RUCPROV;
    private String TELPROV;
    private String EMAPROV;
    private String TIPPROV;
    private String NCOMPROV;
    private String ABREVPROV;
    private String DIRPROV;
    private String IDUBI;
    private String ESTPROV;

    public int getIDPROV() {
        return IDPROV;
    }

    public void setIDPROV(int IDPROV) {
        this.IDPROV = IDPROV;
    }

    public String getNOMPROV() {
        return NOMPROV;
    }

    public void setNOMPROV(String NOMPROV) {
        this.NOMPROV = NOMPROV;
    }

    public String getRUCPROV() {
        return RUCPROV;
    }

    public void setRUCPROV(String RUCPROV) {
        this.RUCPROV = RUCPROV;
    }

    public String getTELPROV() {
        return TELPROV;
    }

    public void setTELPROV(String TELPROV) {
        this.TELPROV = TELPROV;
    }

    public String getEMAPROV() {
        return EMAPROV;
    }

    public void setEMAPROV(String EMAPROV) {
        this.EMAPROV = EMAPROV;
    }

    public String getTIPPROV() {
        return TIPPROV;
    }

    public void setTIPPROV(String TIPPROV) {
        this.TIPPROV = TIPPROV;
    }

    public String getNCOMPROV() {
        return NCOMPROV;
    }

    public void setNCOMPROV(String NCOMPROV) {
        this.NCOMPROV = NCOMPROV;
    }

    public String getABREVPROV() {
        return ABREVPROV;
    }

    public void setABREVPROV(String ABREVPROV) {
        this.ABREVPROV = ABREVPROV;
    }

    public String getDIRPROV() {
        return DIRPROV;
    }

    public void setDIRPROV(String DIRPROV) {
        this.DIRPROV = DIRPROV;
    }

    public String getIDUBI() {
        return IDUBI;
    }

    public void setIDUBI(String IDUBI) {
        this.IDUBI = IDUBI;
    }

    public String getESTPROV() {
        return ESTPROV;
    }

    public void setESTPROV(String ESTPROV) {
        this.ESTPROV = ESTPROV;
    }
    
    

}
