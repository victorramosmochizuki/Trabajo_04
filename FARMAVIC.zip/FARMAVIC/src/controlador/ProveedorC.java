package controlador;

import dao.ProveedorImpl;
import java.util.List;
import modelo.Proveedorm;
import view.Proveedor;
import static view.Proveedor.tipo;

public class ProveedorC {

    Proveedorm pro = new Proveedorm();
    ProveedorImpl dao = new ProveedorImpl();
    List<Proveedorm> listadopro;

    public void registrarC() throws Exception {
        try {
            dao.registrar(pro);
        } catch (Exception e) {
            System.out.println("error en registrarC " + e.getMessage());
        }
    }

    public void variablesModelPRO() {
        try {
//            if ((Proveedor.jLbCodigo.equals(""))) {
//
////            } else {
//                pro.setIDPROV(Integer.parseInt(Proveedor.jLbCodigo.getText()));
//            }
            pro.setNOMPROV(Proveedor.jTxtNombre.getText());
            pro.setRUCPROV(Proveedor.jTxtRuc.getText());
            pro.setTELPROV(Proveedor.jTxtTelefono.getText());
            pro.setEMAPROV(Proveedor.jTxtEmail.getText());
            pro.setTIPPROV(tipo);
            pro.setNCOMPROV(Proveedor.jTxtNcomercial.getText());
            pro.setABREVPROV(Proveedor.jTxtAbrev.getText());
            pro.setDIRPROV(Proveedor.jTxtDireccion.getText());
            pro.setIDUBI(Proveedor.jTxtDistrito.getText());
            pro.setESTPROV("A");
            System.out.println("Estoy en model " + pro.getNOMPROV() + pro.getRUCPROV());
        } catch (Exception e) {
            System.out.println("Error en variablesModelCL " + e.getMessage());
        }
    }

    public static void limpiar() {
        Proveedor.jTxtNombre.setText("");
        Proveedor.jTxtRuc.setText("");
        Proveedor.jTxtTelefono.setText("");
        Proveedor.jTxtEmail.setText("");
        Proveedor.jTxtNcomercial.setText("");
        Proveedor.jTxtAbrev.setText("");
        
        Proveedor.jTxtDireccion.setText("");
        Proveedor.jTxtDistrito.setText("");
        //Proveedor.jCalNac.setDate(new java.util.Date());
      
    }

}
