
package controlador;

import view.ClienteReg;


public class ClienteC {
    
    
    
    public static void limpiarCom(){
        ClienteReg.jTxtNombre.setText("");
        ClienteReg.jTxtApellido.setText("");
        ClienteReg.jTxtDni.setText("");
    }
    
    public void registrar() throws Exception
    
    
}
